===================================
 Apple Health Analyzer - Windows
===================================

Quick Start:
  1. Install Python 3.10+ from https://python.org
     (check "Add Python to PATH" during install)
  2. Double-click install_and_run.bat

Build standalone EXE:
  1. Double-click build_windows.bat
  2. Find EXE in dist\Apple Health Analyzer\

