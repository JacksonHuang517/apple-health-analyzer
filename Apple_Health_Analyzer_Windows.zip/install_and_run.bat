@echo off
chcp 65001 >NUL
echo.
echo  ====================================
echo   Apple Health Analyzer v2.0
echo  ====================================
echo.

python --version 2>NUL
if errorlevel 1 (
    echo [ERROR] Python not found!
    echo Please install Python 3.10+ from https://python.org
    echo Check "Add Python to PATH" during installation.
    pause
    exit /b 1
)

if not exist venv (
    echo [1/3] Creating virtual environment...
    python -m venv venv
)
call venv\Scripts\activate.bat

echo [2/3] Installing dependencies...
pip install customtkinter tkinterdnd2 -q -i https://mirrors.aliyun.com/pypi/simple/

echo [3/3] Starting app...
python HealthCyclingAnalyzer.py
